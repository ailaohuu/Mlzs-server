-- MySQL dump 10.13  Distrib 5.7.43, for Linux (x86_64)
--
-- Host: localhost    Database: mlzs1
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client_auth_tokens`
--

DROP TABLE IF EXISTS `client_auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_auth_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `token_encrypted` text,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` datetime DEFAULT NULL,
  `revoked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_token_hash` (`token_hash`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_token_status` (`token_hash`,`revoked_at`,`expires_at`),
  KEY `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_auth_tokens`
--

LOCK TABLES `client_auth_tokens` WRITE;
/*!40000 ALTER TABLE `client_auth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_config`
--

DROP TABLE IF EXISTS `client_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_config` (
  `master` varchar(64) NOT NULL,
  `device_Id` varchar(32) NOT NULL,
  `server_Uid` varchar(128) NOT NULL DEFAULT '',
  `server_key` varchar(255) NOT NULL DEFAULT '',
  `corp_Id` varchar(128) NOT NULL DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '上传时间',
  PRIMARY KEY (`master`),
  KEY `idx_device` (`device_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_config`
--

LOCK TABLES `client_config` WRITE;
/*!40000 ALTER TABLE `client_config` DISABLE KEYS */;
INSERT INTO `client_config` VALUES ('123213','47744b9a0937975e','','','','2026-08-29 14:28:37'),('测试','47744b9a0937975e','2482','sctp2482t5lbzcdklpudolcufyfqsr9','dingca4e0af9222a2f87f2c783f7214b6d69','2026-08-30 07:39:45'),('测试q','47744b9a0937975e','2482','sctp2482t5lbzcdklpudolcufyfqsr9','dingca4e0af9222a2f87f2c783f7214b6d69','2026-08-30 07:40:30');
/*!40000 ALTER TABLE `client_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `device_id` varchar(32) NOT NULL COMMENT '设备唯一ID',
  `master` varchar(64) NOT NULL DEFAULT '' COMMENT '设备使用人',
  `status` enum('online','offline') NOT NULL DEFAULT 'offline' COMMENT '连接状态',
  `connected_at` datetime NOT NULL COMMENT '最新连接时间',
  `updated_at` datetime NOT NULL COMMENT '最后更新时间',
  `last_active_at` datetime NOT NULL COMMENT '最后活跃时间',
  `last_offline_at` datetime DEFAULT NULL COMMENT '最后离线时间',
  `ip` varchar(45) NOT NULL COMMENT '客户端IP',
  `client_version` varchar(32) NOT NULL DEFAULT 'unknown' COMMENT '客户端版本',
  `reconnect_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '重连次数',
  `battery_level` tinyint(3) unsigned DEFAULT NULL,
  `charging` tinyint(1) DEFAULT NULL,
  `listening` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`device_id`),
  KEY `idx_status` (`status`),
  KEY `idx_last_active` (`last_active_at`),
  KEY `idx_master` (`master`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户端连接状态表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_error_logs`
--

DROP TABLE IF EXISTS `db_error_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_error_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `error_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '错误时间',
  `operation_type` varchar(50) NOT NULL COMMENT '操作类型',
  `device_id` varchar(32) DEFAULT NULL COMMENT '设备ID',
  `error_msg` text NOT NULL COMMENT '错误详情',
  PRIMARY KEY (`id`),
  KEY `idx_device_id` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据库错误日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_error_logs`
--

LOCK TABLES `db_error_logs` WRITE;
/*!40000 ALTER TABLE `db_error_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_error_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_tasks`
--

DROP TABLE IF EXISTS `scheduled_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheduled_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` varchar(190) NOT NULL,
  `master` varchar(190) NOT NULL DEFAULT '',
  `name` varchar(190) NOT NULL,
  `message` text NOT NULL,
  `type` enum('once','daily','weekly') NOT NULL DEFAULT 'daily',
  `fire_time` varchar(5) NOT NULL,
  `fire_date` date DEFAULT NULL,
  `weekdays` varchar(20) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `status` enum('pending','done','missed') NOT NULL DEFAULT 'pending',
  `last_fired_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_device` (`device_id`),
  KEY `idx_enabled` (`enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_tasks`
--

LOCK TABLES `scheduled_tasks` WRITE;
/*!40000 ALTER TABLE `scheduled_tasks` DISABLE KEYS */;
INSERT INTO `scheduled_tasks` VALUES (4,'4b3bae59216c7f61','123213','1','1111','once','11:52','2026-06-04',NULL,1,'done','2026-06-04 11:52:00','2026-06-04 03:51:20'),(5,'4b3bae59216c7f61','123213','11','111','once','12:34','2026-06-04',NULL,1,'done','2026-06-04 12:34:00','2026-06-04 04:33:23'),(6,'4b3bae59216c7f61','123213','1','111','once','12:37','2026-06-04',NULL,1,'done','2026-06-04 12:37:00','2026-06-04 04:36:21'),(7,'4b3bae59216c7f61','123213','11111','11111','once','12:39','2026-06-04',NULL,1,'done','2026-06-04 12:39:00','2026-06-04 04:37:52'),(8,'4b3bae59216c7f61','123213','111','111','once','13:54','2026-06-04',NULL,1,'done','2026-06-04 13:54:00','2026-06-04 05:53:11'),(9,'6eead7156e6b9cc9','张旭楠','上班','张旭楠打卡','daily','08:45',NULL,NULL,1,'pending','2026-08-28 08:45:58','2026-07-09 08:06:17'),(10,'6eead7156e6b9cc9','张旭楠','下班','张旭楠打卡','daily','18:03',NULL,NULL,1,'pending','2026-08-28 18:03:00','2026-07-09 08:06:42'),(11,'74e61c3c98dbc12c','范瑞钧','上班打卡提醒','范瑞钧打卡','daily','08:51',NULL,NULL,1,'pending','2026-08-28 08:51:58','2026-07-10 07:27:03'),(12,'74e61c3c98dbc12c','范瑞钧','下班打卡提醒','范瑞钧打卡','daily','18:01',NULL,NULL,1,'pending','2026-08-28 18:01:00','2026-07-10 07:27:50');
/*!40000 ALTER TABLE `scheduled_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) NOT NULL COMMENT '登录用户名',
  `password` varchar(255) NOT NULL COMMENT '加密密码',
  `realname` varchar(50) NOT NULL COMMENT '真实姓名（与设备master对应）',
  `role` enum('user','admin') NOT NULL DEFAULT 'user' COMMENT '角色',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_realname` (`realname`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'admin','$2b$10$lX.dNdhMCF8vCU2h.KkcYuSLdJNXlNJ/WZoUBTG.S9fE8RbDk/eOq','管理员','admin','2025-11-11 03:11:31'),(6,'王钱旭','$2y$10$tC3DCvDiKYUIrC6p7mXHEea1aIEaX/7L0p.uWfQDsq94ZY1ecHplG','王钱旭','user','2025-11-16 19:41:47'),(10,'TaoQi','$2y$10$VzHito79SUGJgyd2ujGCb.RKIHpc3sOn3mmTEcA454GuF6B5jUlaG','马鸿炜','user','2025-11-24 17:47:20'),(11,'FRJ','$2y$10$sNI/OPPWZ6SLZm7gSUkhe.cav2hYgWOCK/y3ydFgFa8OlMJicoCUy','范瑞钧','user','2025-12-19 11:13:03'),(12,'zxn','$2b$10$sFu.uAnXS503HP9qjE2Dj.DSBSjVmQ6mPQSbPT2Ksi2adHA7NT1Q.','张旭楠','user','2026-08-28 11:19:49'),(13,'text','$2b$10$s1zkPgPZdU0yUi3AVa98guOwJ6qqguRn4OVYtkYetvl0IVsDjGqT.','测试','user','2026-08-30 13:17:58');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mlzs1'
--

--
-- Dumping routines for database 'mlzs1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-30 19:10:04
